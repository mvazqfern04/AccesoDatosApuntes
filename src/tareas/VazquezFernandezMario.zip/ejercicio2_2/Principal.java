/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas.ejercicio2_2;

import java.util.Scanner;
import tareas.ejercicio2_2.BDManager.BDManager;
import tareas.ejercicio2_2.Entidades.Tractor;

/**
 *
 * @author node
 */
public class Principal {

    public static void main(String[] args) {
        BDManager bd = new BDManager();

        bd.abrirConexion();

        //1.Crear2.Modificar 3Eliminar. 4.Consultar 5.Salir
//        String qHacer = "1.Crear" + "\n" + "2.Modificar" + "\n" + "3.Eliminar." + "\n" + "4.Consultar" + "\n" + "5.Salir" + "\n" + "6.Salir";
//        String qTabla = "1.GRANJERO" + "\n" + "2.CONSTRUCCIÓN" + "\n" + "3.TRACTOR" + "\n" + "4.SALIR";
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Que desa hacer?");
//        System.out.println(qHacer);
//        String respuesta = sc.next();
//        while (Integer.parseInt(respuesta) <= 5) {
//            switch (respuesta) {
//                case "1":
//                    System.out.println("Que tabla?: ");
//                    System.out.println(qTabla);
//                    respuesta = sc.next();
//                    insertar(respuesta,bd,sc);
//                    break;
//                case "2":
//
//                    break;
//                case "3":
//
//                    break;
//                case "4":
//
//                    break;
//                case "5":
//
//                    break;
//                default:
//                    break;
//            }
//            obtenerRespuesta(sc);
//        }
//
//        bd.cerrarConexion();

        Tractor tr = new Tractor(1200, 12, 1, "de_carreras", 12.2f, "manana");
        bd.crearTractor(tr);
//        
//        System.out.println(tr.toString());
    }

    private static void obtenerRespuesta(Scanner sc) {
        String respuesta;
        respuesta = sc.next();
    }

    private static void insertar(String respuesta, BDManager bd,Scanner sc) {
        switch (respuesta) {
            case "1":
                
                break;
            case "2":

                break;
            case "3":
                Tractor tractor = new Tractor();
                System.out.println("ID:");
                tractor.setId(Integer.parseInt(sc.next()));
                System.out.println("Id granjero:");
                tractor.setId_granjero(Integer.parseInt(sc.next()));
                System.out.println("Precio venta:");
                tractor.setPrecio_venta(Float.parseFloat(sc.next()));
                System.out.println("Proxima cosecha:");
                tractor.setProxima_cosecha(sc.next());
                System.out.println("Tipo tractor(rural, urbano, cosechar, de_carreras, plantar):");
                tractor.setTipoTractor(sc.next());
                System.out.println("Velocidad: ");
                tractor.setVelocidad(Integer.parseInt(sc.next()));
                bd.crearTractor(tractor);
                break;
            default:
                throw new AssertionError();
        }
    }

}
