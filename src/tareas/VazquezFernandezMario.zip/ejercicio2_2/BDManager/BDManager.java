/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas.ejercicio2_2.BDManager;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import tareas.Ejercicio2_1.OperacionDB;
import tareas.ejercicio2_2.Entidades.*;

/**
 *
 * @author node
 */
public class BDManager {

    private Connection con;
    private Statement stmt;
    
    /**
     * tractores-> id(int) /modelo /velocidad(int) /precio_venta(float) /id_construccion(int)
     * granjeros-> id(int) /nombre /descripcion /dinero(float) /puntos(int) /nivel(int)
     * construcciones-> id(int) /nombre /precio_compra(float) /precio_venta(float) /proxima_cosecha /id_granjero(int)
     */

    public void abrirConexion() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            System.err.println("Excepcionn: " + e.toString());
        }
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/farmville", "root", "abc123.");
            stmt = con.createStatement();

        } catch (SQLException ex) {
            try {
                System.err.println("Error con la clase Connection");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306", "root", "abc123.");
                stmt = con.createStatement();

                stmt.execute("create DATABASE if NOT EXISTS Colegio");
            } catch (SQLException ex1) {
                System.err.println("Error gordo");
            }
        }
    }

    public void cerrarConexion() {
        try {
            //TO-DO
            con.close();
            stmt.close();
        } catch (SQLException ex) {
            Logger.getLogger(OperacionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Crear->granjero/construccion/tractor
    
    public void crearTractor(Tractor tractor){
        try {
            String stringSQL = "INSERT INTO tractores (id, modelo, velocidad, precio_venta, id_construccion) VALUES (?, ?, ?, ?,?)";
            //String granjSent = "INSERT INTO granjeros (id,nombre, descripcion, dinero,puntos, nivel) VALUES (?, ?, ?, ?,?,?)";
            //String constSent = "INSERT INTO construcciones (id, nombre,precio_compra, precio_venta, proxima_cosecha, id_granjero) VALUES (?, ?, ?, ?,?,?)";
            PreparedStatement sentencia = null;
            
            sentencia=con.prepareStatement(stringSQL);
            sentencia.setInt(1, tractor.getId());
            sentencia.setString(2, tractor.getTipoTractor());
            sentencia.setInt(3,tractor.getVelocidad());
            sentencia.setFloat(4, tractor.getPrecio_venta());
            sentencia.setInt(5, tractor.getId_granjero());
            
            sentencia.executeUpdate();
            sentencia.close();
        } catch (SQLException ex) {
            Logger.getLogger(BDManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    //Eliminar->granjero/construccion/tractor
    //Modificar->granjero/construccion/tractor
    //Leer->granjero/construccion/tractor
}
